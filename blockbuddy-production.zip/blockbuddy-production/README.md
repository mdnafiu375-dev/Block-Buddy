# BlockBuddy — production-style starter

A shareable friendship quiz website with an Express API, persistent SQLite database, per-quiz leaderboard, and global leaderboard. It extends the original single-file prototype into a client/server application.

## Features

- Create a quiz by selecting the creator's intended answer for each question.
- Generates a durable URL such as `/q/AbCdEf123`.
- Friends can open that link on other devices and submit scores.
- Server-side score calculation; the browser never receives correct answers from the quiz-read API.
- SQLite persistence for quizzes and attempts.
- Per-quiz top 10 and global top 20 leaderboard.
- Responsive dark/neon UI, animated results, confetti, and sound toggle.
- Basic security headers, request-size limit, input validation, and parameterized SQL.

## Requirements

- Node.js 20+
- npm

## Run locally

```bash
npm install
cp .env.example .env
npm start
```

Open `http://localhost:3000`. The database is created automatically at `./data/blockbuddy.sqlite`.

## Deploy to Render (persistent disk required)

1. Push this folder to a GitHub repository.
2. In Render, create a **Web Service** from that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add a **Persistent Disk** mounted at `/var/data`.
6. Set environment variables:
   - `DATABASE_FILE=/var/data/blockbuddy.sqlite`
   - `NODE_ENV=production`
7. Deploy and test `/api/health`.
8. The public URL is the permanent base domain; quiz URLs are generated from the incoming request host.

Do not deploy with an ephemeral filesystem if you need quiz links and scores to survive restarts/redeploys. SQLite is appropriate for a small launch. For a larger multi-instance deployment, move storage to managed PostgreSQL and add abuse controls.

## API

- `GET /api/health`
- `POST /api/quizzes` — `{ creatorName, questions }`
- `GET /api/quizzes/:id` — public quiz questions, correct answers withheld
- `POST /api/quizzes/:id/attempts` — `{ playerName, answers: [0,1,...] }`
- `GET /api/quizzes/:id/leaderboard`
- `GET /api/leaderboard`

## Before a public/viral launch

This is a working production-style starter, not a fully hardened high-traffic service. Add rate limiting, CAPTCHA/abuse prevention, moderation/reporting, automated tests, database backups, privacy/retention rules, and a managed database before a large public launch. Since the leaderboard is global and names are user-entered, display names are not verified identities.
