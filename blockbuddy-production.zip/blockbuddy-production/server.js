const express = require('express');
const helmet = require('helmet');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dbFile = process.env.DATABASE_FILE || path.join(__dirname, 'data', 'blockbuddy.sqlite');
fs.mkdirSync(path.dirname(path.resolve(dbFile)), { recursive: true });
const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS quizzes (
 id TEXT PRIMARY KEY, creator_name TEXT NOT NULL, questions_json TEXT NOT NULL,
 created_at TEXT NOT NULL, plays INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS attempts (
 id INTEGER PRIMARY KEY AUTOINCREMENT, quiz_id TEXT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
 player_name TEXT NOT NULL, score INTEGER NOT NULL CHECK(score BETWEEN 0 AND 100),
 correct_count INTEGER NOT NULL, total_questions INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS attempts_score_idx ON attempts(score DESC, created_at ASC);
CREATE INDEX IF NOT EXISTS attempts_quiz_idx ON attempts(quiz_id, score DESC);
`);
app.disable('x-powered-by');
// Respect the HTTPS scheme forwarded by platforms such as Render.
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '40kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const cleanText = (value, max=40) => String(value ?? '').replace(/[<>]/g, '').trim().slice(0, max);
const safeId = id => /^[a-zA-Z0-9_-]{6,32}$/.test(String(id || ''));
const defaultQuestions = [
 { emoji:'🍕', q:'What is my go-to late-night snack?', opts:['Pizza 🍕','Something sweet 🍩','Instant noodles 🍜','Whatever is nearby 😌'] },
 { emoji:'💬', q:'How quickly do I reply to messages?', opts:['Instantly 📱','When I remember 😭','Three business days','In my head only'] },
 { emoji:'🎬', q:'What is my ideal movie night?', opts:['Horror 👻','Rom-com 💗','Action 💥','Comfort show on repeat'] },
 { emoji:'🌴', q:'Pick my dream hangout', opts:['Beach day 🌊','Shopping 🛍️','Gaming 🎮','Road trip 🚗'] },
 { emoji:'🤫', q:'If I say “I have tea”, what do you do?', opts:['Drop everything ☕','Ask if it is actual tea','Tell me EVERYTHING','Pretend to be busy'] },
 { emoji:'🫶', q:'What matters most in a friendship?', opts:['Honesty 💯','Same taste','Never disagreeing','Perfect photos'] }
];
function validateQuestions(input) {
 if (!Array.isArray(input) || input.length < 3 || input.length > 12) throw new Error('A quiz needs 3–12 questions.');
 return input.map((q, i) => {
   const prompt = cleanText(q.q, 140);
   const opts = Array.isArray(q.opts) ? q.opts.slice(0, 4).map(v => cleanText(v, 90)) : [];
   const correct = Number(q.correct);
   if (!prompt || opts.length !== 4 || opts.some(x => !x) || !Number.isInteger(correct) || correct < 0 || correct > 3) {
     throw new Error(`Question ${i+1} is incomplete.`);
   }
   return { emoji: cleanText(q.emoji || '✨', 8), q: prompt, opts, correct };
 });
}
app.get('/api/health', (req, res) => res.json({ ok:true, service:'BlockBuddy API', storage:'sqlite' }));
app.post('/api/quizzes', (req, res) => {
 try {
   const creator = cleanText(req.body.creatorName, 28);
   if (creator.length < 1) return res.status(400).json({ error:'Please enter your name.' });
   const questions = validateQuestions(req.body.questions);
   const id = crypto.randomBytes(6).toString('base64url');
   const createdAt = new Date().toISOString();
   db.prepare('INSERT INTO quizzes(id, creator_name, questions_json, created_at) VALUES(?,?,?,?)')
     .run(id, creator, JSON.stringify(questions), createdAt);
   res.status(201).json({ id, creatorName:creator, createdAt, url:`${req.protocol}://${req.get('host')}/q/${id}` });
 } catch (e) { res.status(400).json({ error:e.message || 'Could not create quiz.' }); }
});
app.get('/api/quizzes/:id', (req, res) => {
 const id = req.params.id;
 if (!safeId(id)) return res.status(400).json({ error:'Invalid quiz link.' });
 const row = db.prepare('SELECT id, creator_name, questions_json, created_at, plays FROM quizzes WHERE id=?').get(id);
 if (!row) return res.status(404).json({ error:'This quiz link was not found. Ask your friend to create a new one.' });
 const questions = JSON.parse(row.questions_json).map(({emoji,q,opts}) => ({emoji,q,opts}));
 res.json({ id:row.id, creatorName:row.creator_name, questions, createdAt:row.created_at, plays:row.plays });
});
app.post('/api/quizzes/:id/attempts', (req, res) => {
 try {
   const id = req.params.id;
   if (!safeId(id)) return res.status(400).json({ error:'Invalid quiz link.' });
   const quiz = db.prepare('SELECT id, questions_json FROM quizzes WHERE id=?').get(id);
   if (!quiz) return res.status(404).json({ error:'Quiz not found.' });
   const playerName = cleanText(req.body.playerName, 28);
   const answers = req.body.answers;
   const questions = JSON.parse(quiz.questions_json);
   if (!playerName) return res.status(400).json({ error:'Enter your name to save your score.' });
   if (!Array.isArray(answers) || answers.length !== questions.length || answers.some(a => !Number.isInteger(a) || a < 0 || a > 3))
     return res.status(400).json({ error:'Please answer every question.' });
   const correctCount = answers.reduce((sum, answer, i) => sum + (answer === questions[i].correct ? 1 : 0), 0);
   const score = Math.round(correctCount / questions.length * 100);
   const createdAt = new Date().toISOString();
   const result = db.transaction(() => {
     db.prepare('INSERT INTO attempts(quiz_id,player_name,score,correct_count,total_questions,created_at) VALUES(?,?,?,?,?,?)')
       .run(id, playerName, score, correctCount, questions.length, createdAt);
     db.prepare('UPDATE quizzes SET plays=plays+1 WHERE id=?').run(id);
     return db.prepare('SELECT last_insert_rowid() AS id').get().id;
   })();
   const leaderboard = db.prepare(`SELECT player_name AS name, score, correct_count AS correctCount,
     total_questions AS totalQuestions, created_at AS createdAt FROM attempts WHERE quiz_id=?
     ORDER BY score DESC, created_at ASC LIMIT 10`).all(id);
   res.status(201).json({ attemptId:result, score, correctCount, totalQuestions:questions.length, leaderboard });
 } catch (e) { res.status(400).json({ error:e.message || 'Could not save this score.' }); }
});
app.get('/api/quizzes/:id/leaderboard', (req, res) => {
 const id = req.params.id;
 if (!safeId(id)) return res.status(400).json({ error:'Invalid quiz link.' });
 const quiz = db.prepare('SELECT creator_name, plays FROM quizzes WHERE id=?').get(id);
 if (!quiz) return res.status(404).json({ error:'Quiz not found.' });
 const entries = db.prepare(`SELECT player_name AS name, score, correct_count AS correctCount,
   total_questions AS totalQuestions, created_at AS createdAt FROM attempts WHERE quiz_id=?
   ORDER BY score DESC, created_at ASC LIMIT 10`).all(id);
 res.json({ creatorName:quiz.creator_name, plays:quiz.plays, entries });
});
app.get('/api/leaderboard', (req, res) => {
 const entries = db.prepare(`SELECT a.player_name AS name, a.score, a.correct_count AS correctCount,
   a.total_questions AS totalQuestions, a.created_at AS createdAt, q.creator_name AS quizCreator, q.id AS quizId
   FROM attempts a JOIN quizzes q ON q.id=a.quiz_id ORDER BY a.score DESC, a.created_at ASC LIMIT 20`).all();
 const stats = db.prepare('SELECT (SELECT COUNT(*) FROM quizzes) AS quizzes, (SELECT COUNT(*) FROM attempts) AS plays').get();
 res.json({ entries, stats });
});
app.get('/q/:id', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`BlockBuddy running at http://localhost:${PORT}`));
