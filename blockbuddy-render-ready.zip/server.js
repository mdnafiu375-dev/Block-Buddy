const express = require('express');
const helmet = require('helmet');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dbFile = process.env.DATABASE_FILE || path.join(__dirname, 'data', 'blockbuddy.sqlite');
fs.mkdirSync(path.dirname(path.resolve(dbFile)), { recursive: true });
const db = new Database(dbFile);
db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at TEXT NOT NULL, expires_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS quizzes (id TEXT PRIMARY KEY, creator_name TEXT NOT NULL, questions_json TEXT NOT NULL, created_at TEXT NOT NULL, plays INTEGER NOT NULL DEFAULT 0, user_id TEXT REFERENCES users(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS attempts (id INTEGER PRIMARY KEY AUTOINCREMENT, quiz_id TEXT NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE, player_name TEXT NOT NULL, score INTEGER NOT NULL CHECK(score BETWEEN 0 AND 100), correct_count INTEGER NOT NULL, total_questions INTEGER NOT NULL, created_at TEXT NOT NULL, ip_hash TEXT);
CREATE INDEX IF NOT EXISTS attempts_score_idx ON attempts(score DESC, created_at ASC);
CREATE INDEX IF NOT EXISTS attempts_quiz_idx ON attempts(quiz_id, score DESC);
`);
function ensureColumn(table, column, definition) { const cols = db.prepare(`PRAGMA table_info(${table})`).all(); if (!cols.some(c => c.name === column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`); }
ensureColumn('quizzes', 'user_id', 'TEXT REFERENCES users(id) ON DELETE SET NULL');
ensureColumn('attempts', 'ip_hash', 'TEXT');
db.exec('CREATE INDEX IF NOT EXISTS quizzes_owner_idx ON quizzes(user_id, created_at DESC)');
app.disable('x-powered-by'); app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false })); app.use(express.json({ limit: '40kb' }));

// Lightweight in-memory rate limits. Use a shared store (e.g. Redis) when horizontally scaling.
const rateBuckets = new Map();
function rateLimit({ windowMs = 60_000, max = 30, key = req => req.ip, message = 'Too many requests. Please wait a little and try again.' } = {}) {
 return (req, res, next) => { const now = Date.now(), k = key(req); let b = rateBuckets.get(k); if (!b || now - b.start > windowMs) b = { start: now, count: 0 }; b.count++; rateBuckets.set(k, b); if (b.count > max) return res.status(429).json({ error: message }); next(); };
}
setInterval(() => { const now = Date.now(); for (const [k,b] of rateBuckets) if (now-b.start > 10*60_000) rateBuckets.delete(k); }, 5*60_000).unref();
const cleanText = (v, max=40) => String(v ?? '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0,max);
const safeId = id => /^[a-zA-Z0-9_-]{6,32}$/.test(String(id || ''));
const hash = s => crypto.createHash('sha256').update(String(s)).digest('hex');
const passwordHash = (password, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, digest: crypto.scryptSync(password, salt, 64).toString('hex') });
function verifyPassword(password, stored) { try { const [salt, digest] = stored.split(':'); const actual = crypto.scryptSync(password, salt, 64); const expected = Buffer.from(digest, 'hex'); return actual.length === expected.length && crypto.timingSafeEqual(actual, expected); } catch { return false; } }
function auth(req, res, next) { const raw = (req.headers.authorization || '').replace(/^Bearer\s+/i, ''); if (!raw) return res.status(401).json({ error: 'Please sign in to manage your quizzes.' }); const session = db.prepare('SELECT s.user_id, u.username, u.email FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?').get(hash(raw), new Date().toISOString()); if (!session) return res.status(401).json({ error: 'Your session expired. Please sign in again.' }); req.user = { id: session.user_id, username: session.username, email: session.email }; next(); }
function issueSession(userId) { const token = crypto.randomBytes(32).toString('base64url'); const now = new Date(); db.prepare('INSERT INTO sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').run(hash(token), userId, now.toISOString(), new Date(now.getTime()+30*86400000).toISOString()); return token; }
function validateQuestions(input) {
 if (!Array.isArray(input) || input.length < 3 || input.length > 12) throw new Error('A quiz needs 3–12 questions.');
 return input.map((q,i) => { const prompt=cleanText(q.q,140), opts=Array.isArray(q.opts)?q.opts.slice(0,4).map(v=>cleanText(v,90)):[], correct=Number(q.correct); if(!prompt||opts.length!==4||opts.some(x=>!x)||new Set(opts.map(x=>x.toLowerCase())).size!==4||!Number.isInteger(correct)||correct<0||correct>3) throw new Error(`Question ${i+1} needs a question, four different answers, and one selected correct answer.`); return {emoji:cleanText(q.emoji||'✨',8),q:prompt,opts,correct}; });
}
const defaultQuestions = [
 {emoji:'🍕',q:'What is my go-to late-night snack?',opts:['Pizza 🍕','Something sweet 🍩','Instant noodles 🍜','Whatever is nearby 😌'],correct:0},
 {emoji:'💬',q:'How quickly do I reply to messages?',opts:['Instantly 📱','When I remember 😭','Three business days','In my head only'],correct:0},
 {emoji:'🎬',q:'What is my ideal movie night?',opts:['Horror 👻','Rom-com 💗','Action 💥','Comfort show on repeat'],correct:0},
 {emoji:'🌴',q:'Pick my dream hangout',opts:['Beach day 🌊','Shopping 🛍️','Gaming 🎮','Road trip 🚗'],correct:0},
 {emoji:'🤫',q:'If I say “I have tea”, what do you do?',opts:['Drop everything ☕','Ask if it is actual tea','Tell me EVERYTHING','Pretend to be busy'],correct:0},
 {emoji:'🫶',q:'What matters most in a friendship?',opts:['Honesty 💯','Same taste','Never disagreeing','Perfect photos'],correct:0}
];
app.get('/api/health',(req,res)=>res.json({ok:true,service:'BlockBuddy API',storage:'sqlite',features:['accounts','quiz-management','leaderboards','rate-limits']}));
app.post('/api/auth/register',rateLimit({max:8,windowMs:15*60_000}), (req,res)=>{
 const username=cleanText(req.body.username,24), email=cleanText(req.body.email,120).toLowerCase(), password=String(req.body.password||'');
 if(!/^[\p{L}\p{N}_.-]{3,24}$/u.test(username)) return res.status(400).json({error:'Username must be 3–24 characters (letters, numbers, . _ -).'});
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:'Enter a valid email address.'});
 if(password.length<8||password.length>128) return res.status(400).json({error:'Password must be at least 8 characters.'});
 const p=passwordHash(password), id=crypto.randomBytes(12).toString('base64url');
 try { db.prepare('INSERT INTO users(id,username,email,password_hash,created_at) VALUES(?,?,?,?,?)').run(id,username,email,`${p.salt}:${p.digest}`,new Date().toISOString()); const token=issueSession(id); res.status(201).json({token,user:{id,username,email}}); }
 catch(e){res.status(409).json({error:'That username or email is already registered.'});}
});
app.post('/api/auth/login',rateLimit({max:12,windowMs:15*60_000}), (req,res)=>{ const identity=cleanText(req.body.identity,120), password=String(req.body.password||''); const u=db.prepare('SELECT * FROM users WHERE username=? COLLATE NOCASE OR email=? COLLATE NOCASE').get(identity,identity); if(!u||!verifyPassword(password,u.password_hash)) return res.status(401).json({error:'Email/username or password is incorrect.'}); const token=issueSession(u.id); res.json({token,user:{id:u.id,username:u.username,email:u.email}}); });
app.get('/api/auth/me',auth,(req,res)=>res.json({user:req.user}));
app.post('/api/auth/logout',auth,(req,res)=>{const raw=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hash(raw));res.json({ok:true});});
app.get('/api/me/quizzes',auth,(req,res)=>{const rows=db.prepare('SELECT id,creator_name AS creatorName,created_at AS createdAt,plays FROM quizzes WHERE user_id=? ORDER BY created_at DESC').all(req.user.id);res.json({quizzes:rows});});
app.delete('/api/me/quizzes/:id',auth,(req,res)=>{const result=db.prepare('DELETE FROM quizzes WHERE id=? AND user_id=?').run(req.params.id,req.user.id);if(!result.changes)return res.status(404).json({error:'Quiz not found or you do not own it.'});res.json({ok:true});});
app.post('/api/quizzes',rateLimit({max:10,windowMs:10*60_000}), (req,res)=>{
 try {const creator=cleanText(req.body.creatorName,28);if(!creator)return res.status(400).json({error:'Please enter your name.'});const questions=validateQuestions(req.body.questions);const id=crypto.randomBytes(9).toString('base64url'),createdAt=new Date().toISOString();const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');let userId=null;if(token){const s=db.prepare('SELECT user_id FROM sessions WHERE token_hash=? AND expires_at>?').get(hash(token),createdAt);if(s)userId=s.user_id;}
 db.prepare('INSERT INTO quizzes(id,creator_name,questions_json,created_at,user_id) VALUES(?,?,?,?,?)').run(id,creator,JSON.stringify(questions),createdAt,userId);res.status(201).json({id,creatorName:creator,createdAt,url:`${req.protocol}://${req.get('host')}/q/${id}`,owned:!!userId});}
 catch(e){res.status(400).json({error:e.message||'Could not create quiz.'});}
});
app.get('/api/quizzes/:id',(req,res)=>{const id=req.params.id;if(!safeId(id))return res.status(400).json({error:'Invalid quiz link.'});const row=db.prepare('SELECT id,creator_name,questions_json,created_at,plays FROM quizzes WHERE id=?').get(id);if(!row)return res.status(404).json({error:'This quiz link was not found. Ask your friend to create a new one.'});const questions=JSON.parse(row.questions_json).map(({emoji,q,opts})=>({emoji,q,opts}));res.json({id:row.id,creatorName:row.creator_name,questions,createdAt:row.created_at,plays:row.plays});});
app.post('/api/quizzes/:id/attempts',rateLimit({max:15,windowMs:60_000,message:'You are submitting scores too quickly. Please wait a minute.'}),(req,res)=>{
 try{const id=req.params.id;if(!safeId(id))return res.status(400).json({error:'Invalid quiz link.'});const quiz=db.prepare('SELECT id,questions_json FROM quizzes WHERE id=?').get(id);if(!quiz)return res.status(404).json({error:'Quiz not found.'});const playerName=cleanText(req.body.playerName,28),answers=req.body.answers,questions=JSON.parse(quiz.questions_json);if(!playerName)return res.status(400).json({error:'Enter your name to save your score.'});if(!Array.isArray(answers)||answers.length!==questions.length||answers.some(a=>!Number.isInteger(a)||a<0||a>3))return res.status(400).json({error:'Please answer every question.'});const ipHash=hash(req.ip||'unknown');const recent=db.prepare('SELECT created_at FROM attempts WHERE quiz_id=? AND ip_hash=? AND created_at>? ORDER BY id DESC LIMIT 1').get(id,ipHash,new Date(Date.now()-20_000).toISOString());if(recent)return res.status(429).json({error:'A score was just submitted from this network. Please wait 20 seconds before trying again.'});const correctCount=answers.reduce((s,a,i)=>s+(a===questions[i].correct?1:0),0),score=Math.round(correctCount/questions.length*100),createdAt=new Date().toISOString();const attemptId=db.transaction(()=>{db.prepare('INSERT INTO attempts(quiz_id,player_name,score,correct_count,total_questions,created_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run(id,playerName,score,correctCount,questions.length,createdAt,ipHash);db.prepare('UPDATE quizzes SET plays=plays+1 WHERE id=?').run(id);return db.prepare('SELECT last_insert_rowid() AS id').get().id;})();const leaderboard=db.prepare('SELECT player_name AS name,score,correct_count AS correctCount,total_questions AS totalQuestions,created_at AS createdAt FROM attempts WHERE quiz_id=? ORDER BY score DESC,created_at ASC LIMIT 10').all(id);res.status(201).json({attemptId,score,correctCount,totalQuestions:questions.length,leaderboard});}
 catch(e){res.status(400).json({error:e.message||'Could not save this score.'});}
});
app.get('/api/quizzes/:id/leaderboard',(req,res)=>{const id=req.params.id;if(!safeId(id))return res.status(400).json({error:'Invalid quiz link.'});const quiz=db.prepare('SELECT creator_name,plays FROM quizzes WHERE id=?').get(id);if(!quiz)return res.status(404).json({error:'Quiz not found.'});const entries=db.prepare('SELECT player_name AS name,score,correct_count AS correctCount,total_questions AS totalQuestions,created_at AS createdAt FROM attempts WHERE quiz_id=? ORDER BY score DESC,created_at ASC LIMIT 10').all(id);res.json({creatorName:quiz.creator_name,plays:quiz.plays,entries});});
app.get('/api/leaderboard',(req,res)=>{const entries=db.prepare('SELECT a.player_name AS name,a.score,a.correct_count AS correctCount,a.total_questions AS totalQuestions,a.created_at AS createdAt,q.creator_name AS quizCreator,q.id AS quizId FROM attempts a JOIN quizzes q ON q.id=a.quiz_id ORDER BY a.score DESC,a.created_at ASC LIMIT 20').all();const stats=db.prepare('SELECT (SELECT COUNT(*) FROM quizzes) AS quizzes,(SELECT COUNT(*) FROM attempts) AS plays').get();res.json({entries,stats});});
app.get('/q/:id',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`BlockBuddy running at http://localhost:${PORT}`));
