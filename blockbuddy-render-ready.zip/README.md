# BlockBuddy — full-stack friendship quiz

A responsive friendship-quiz website with a Node.js/Express API, SQLite persistence, custom question editor, user accounts, quiz management, scoreboards, anti-spam checks, sound effects, and animated results.

## What's included

- **Custom quiz editor:** edit question text, emoji, all four answer choices, select the correct answer, add/remove questions (3–12 per quiz).
- **Shareable quiz links:** every published quiz receives a stable `/q/:id` URL.
- **User accounts:** register and sign in with username/email and password. Passwords are salted and hashed with Node's `scrypt`; sessions use random bearer tokens stored as hashes and expire after 30 days.
- **Quiz management:** signed-in users can see their own quizzes, open/copy links, and delete quizzes from the dashboard. Quizzes made while signed out remain public but are not attached to an account.
- **Leaderboards:** per-quiz top 10 and global top 20.
- **Anti-spam basics:** per-IP request throttles on account creation/login, quiz creation and score submission; repeated submissions from the same network to the same quiz within 20 seconds are rejected; server calculates the score.
- **Mobile-friendly UI:** responsive layout, animated screen transitions, progress indicator, result confetti, synthesized sound effects and sound toggle.
- **Security basics:** Helmet headers, JSON body limit, input validation, parameterized SQL, password hashing, server-side ownership checks and no correct answers in public quiz-read responses.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

```bash
npm install
cp .env.example .env
npm start
```

Open `http://localhost:3000`. SQLite is created automatically at `./data/blockbuddy.sqlite`.

## Deploy to Render

1. Push the contents of this folder to a GitHub repository.
2. In Render, create a **Web Service** from the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add a **Persistent Disk** mounted at `/var/data`.
6. Set `DATABASE_FILE=/var/data/blockbuddy.sqlite` and `NODE_ENV=production`.
7. Deploy and test `https://YOUR-SERVICE.onrender.com/api/health`.

Do not use an ephemeral filesystem if quizzes, accounts and scores must survive redeploys. Use HTTPS in production. Back up the database regularly.

## API overview

- `GET /api/health`
- `POST /api/auth/register` — `{ username, email, password }`
- `POST /api/auth/login` — `{ identity, password }`
- `GET /api/auth/me` — bearer token required
- `POST /api/auth/logout` — bearer token required
- `GET /api/me/quizzes` — bearer token required
- `DELETE /api/me/quizzes/:id` — owner only
- `POST /api/quizzes` — `{ creatorName, questions }`; optional bearer token associates it with the signed-in user
- `GET /api/quizzes/:id` — correct answers withheld
- `POST /api/quizzes/:id/attempts` — `{ playerName, answers: [0,1,...] }`
- `GET /api/quizzes/:id/leaderboard`
- `GET /api/leaderboard`

## Deployment and security notes

This is a runnable full-stack starter, not a claim of enterprise-grade hardening. Rate limits are in-memory and reset when the process restarts; they are not shared between multiple instances. For a large public launch, use Redis-backed rate limiting, CAPTCHA/bot detection, email verification/password reset, moderation/reporting, automated tests, database backups, privacy/retention policies, and managed PostgreSQL for multi-instance scale. Public leaderboard names are unverified display names. Do not put secrets in client-side code.
